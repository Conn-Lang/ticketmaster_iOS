//
//  NameSearchList.swift
//  ticketmaster_ios
//
//  Created by Hayden Langston on 4/13/22.
//

import SwiftUI

struct NameSearchList: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct NameSearchList_Previews: PreviewProvider {
    static var previews: some View {
        NameSearchList()
    }
}
