//
//  Constants.swift
//  ticketmaster_ios
//
//  Created by Dylan Bolter on 4/19/22.
//

import Foundation


struct Constants {
    static let baseUrl = ---------------------------------------
    //This variable is specific to the Pattonville School District. Since the servers are still running, this variable has been scrubbed for the security of the system.
}
