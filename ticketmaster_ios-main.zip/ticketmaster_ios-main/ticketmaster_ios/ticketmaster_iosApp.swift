//
//  ticketmaster_iosApp.swift
//  ticketmaster_ios
//
//  Created by Dylan Bolter on 9/28/21.
//

import SwiftUI
import GoogleSignIn

@main
struct ticketmaster_iosApp: App {
    
    var body: some Scene {
        WindowGroup {
            WelcomePage()
        }
    }
}

